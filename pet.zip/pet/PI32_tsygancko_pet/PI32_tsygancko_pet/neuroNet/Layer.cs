﻿using System;
using System.IO;
using System.Windows.Forms;

namespace PI32_tsygancko_pet.neuroNet
{
    abstract class Layer
    {
        //поля
        protected string name_Layer; // Наименования слоя который используется
        string pathDirWeights; //путь к дирректории в которой лежат веса
        string pathFileWeights; //путь к файлу в котором лежат веса
        protected int numofneurons; //число нейронов этого слоя
        protected int numofprevneurons; //число нейронов предыдущего слоя
        protected const double learningrate = 0.05d; //скорость обучения
        protected const double momentum = 0.050d; //момент инерции
        protected double[,] lastdeltaweights; //веса предыдущей итерации обучения
        protected Neuron[] neurons; //массив нейронов текущео слоя







        //Свойства

        public double[] Data //передача входных данных на след слой
        {
            set
            {
                for(int i = 0;i < numofneurons; i++)
                {
                    neurons[i].Activator(value);
                }
            }
        }

        //Конструктор
        protected Layer(int non, int nopn, NeuronType nt, string nm_Layer)
        {
            numofneurons = non;
            numofprevneurons = nopn;
            neurons = new Neuron[non];
            name_Layer = nm_Layer;
            pathDirWeights = AppDomain.CurrentDomain.BaseDirectory + "memory\\";
            pathFileWeights = pathDirWeights + name_Layer + "_memory.csv";

            lastdeltaweights = new double[non, nopn + 1];
            double[,] Weights;


            if (File.Exists(pathFileWeights))
                Weights = WeightInitialize(MemoryMode.GET, pathFileWeights);
            else
            {
                Directory.CreateDirectory(pathDirWeights);
                Weights = WeightInitialize(MemoryMode.INIT, pathFileWeights);
            }

            for(int i = 0; i < non; i++)
            {
                double[] tmp_weights = new double[nopn + 1];
                for ( int j = 0;j < nopn; j++)
                {
                    tmp_weights[j] = Weights[i, j];
                }
                neurons[i] = new Neuron(tmp_weights, nt);
            }
        }

        public double[,] WeightInitialize(MemoryMode mm, string path)
        {
            return new double[1,1];
        }
    }
}
