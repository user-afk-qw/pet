﻿
namespace PI32_tsygancko_pet.neuroNet
{
    enum MemoryMode
    {
        GET,
        SET,
        INIT
    }

    enum NeuronType
    {
        Hidden,
        Output
    }

    enum NetworkMOde
    {
        Train,
        Test,
        Demo
    }
}
