﻿using static System.Math;
using System;

namespace PI32_tsygancko_pet.neuroNet
{
    class Neuron
    {
        //поля нейрон №РЕлу Утекающий
        //Функция Активации Лелу
        //Месрапян Логистическая 
        //Мотыжев гиперболический тангенс
        private NeuronType type;
        private double[] weights;
        private double[] inputs;
        private double output;
        private double derivative;

        //констаны для функции активации
        private double a = 0.01d;

        //Свойства

        public double[] Weights { get => weights; set => weights = value; }
        public double[] Inputs { get => inputs; set => inputs = value; }
        public double Output { get => output; }
        public double Derivative { get => derivative; }
        public Neuron(double[] memoryWeights, NeuronType typeNeuron)
        {
            type = typeNeuron;
            weights = memoryWeights;
        }

        public void Activator(double[] i)
        {
            inputs = i;
            double sum = weights[0]; // bias

            for (int j = 0; j < inputs.Length; j++)
            {
                sum += inputs[j] * weights[j + 1]; // умножение!
            }

            switch (type)
            {
                case NeuronType.Hidden:
                    output = leakyReLU(sum);
                    derivative = LeakyReLU_Derivativater(sum);
                    break;

                case NeuronType.Output:
                    output = Exp(sum);
                    derivative = Exp(sum); // производная экспоненты = сама экспонента
                    break;
            }

            double leakyReLU(double x) => x > 0 ? x : 0.01 * x;
            double LeakyReLU_Derivativater(double x) => x > 0 ? 1 : 0.01;

            double Exp(double x) => Math.Exp(x);
        }


    }
}
