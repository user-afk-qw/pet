﻿using static System.Math;

namespace PI32_tsygancko_pet.neuroNet
{
    class Neuron
    {
        //поля нейрон №РЕлу Утекающий
        //Функция Активации Лелу
        //Месрапян Логистическая 
        //Мотыжев гиперболический тангенс
        private NeuronType type;
        private double[] weights;
        private double[] inputs;
        private double output;
        private double derivative;

        //констаны для функции активации
        private double a = 0.01d;

        //Свойства

        public double[] Weights { get => weights; set => weights = value; }
        public double[] Inputs { get => inputs; set => inputs = value; }
        public double Output { get => output; }
        public double Derivative { get => derivative; }
        public Neuron(double[] memoryWeights, NeuronType typeNeuron)
        {
            type = typeNeuron;
            weights = memoryWeights;
        }
    }
}
