﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PI32_tsygancko_pet.neuroNet
{
    class Network
    {
    }
}
